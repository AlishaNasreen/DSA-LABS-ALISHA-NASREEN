#include <iostream>
#include <vector>
using namespace std;

class CircularQueue {
private:
    int size, front, rear;
    vector<int> queue; // ArrayList in Java

public:
    // Constructor
    CircularQueue(int size) {
        this->size = size;
        this->front = this->rear = -1;
        queue.resize(size); // allocate space
    }

    // Function to insert (enqueue) element
    void enQueue(int data) {
        // If queue is full
        if ((front == 0 && rear == size - 1) ||
            (rear == (front - 1 + size) % size)) {
            cout << "Queue is Full" << endl;
            return;
        }

        // If queue is empty
        else if (front == -1) {
            front = rear = 0;
            queue[rear] = data;
        }

        // If rear reached end but space available at front
        else if (rear == size - 1 && front != 0) {
            rear = 0;
            queue[rear] = data;
        }

        // Normal enqueue
        else {
            rear++;
            queue[rear] = data;
        }

        cout << "Enqueued: " << data << endl;
    }

    // Function to delete (dequeue) element
    int deQueue() {
        if (front == -1) {
            cout << "Queue is Empty" << endl;
            return -1;
        }

        int temp = queue[front];

        // Only one element left
        if (front == rear) {
            front = rear = -1;
        }

        // Move front ahead circularly
        else if (front == size - 1) {
            front = 0;
        }

        else {
            front++;
        }

        return temp;
    }

    // Function to display queue elements
    void displayQueue() {
        if (front == -1) {
            cout << "Queue is Empty" << endl;
            return;
        }

        cout << "Elements in the circular queue are: ";

        if (rear >= front) {
            for (int i = front; i <= rear; i++)
                cout << queue[i] << " ";
        } else {
            for (int i = front; i < size; i++)
                cout << queue[i] << " ";
            for (int i = 0; i <= rear; i++)
                cout << queue[i] << " ";
        }
        cout << endl;
    }
};

// Driver code
int main() {
    CircularQueue q(5);

    q.enQueue(14);
    q.enQueue(22);
    q.enQueue(13);
    q.enQueue(-6);

    q.displayQueue();

    int x = q.deQueue();
    if (x != -1)
        cout << "Deleted value = " << x << endl;

    x = q.deQueue();
    if (x != -1)
        cout << "Deleted value = " << x << endl;

    q.displayQueue();

    q.enQueue(9);
    q.enQueue(20);
    q.enQueue(5);

    q.displayQueue();

    q.enQueue(20); // Should show "Queue is Full"

    return 0;
}
