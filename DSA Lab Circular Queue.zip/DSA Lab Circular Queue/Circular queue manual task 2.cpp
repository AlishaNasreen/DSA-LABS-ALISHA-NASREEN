#include <iostream>
using namespace std;

const int QUEUE_CAPACITY = 128;

class Queue {
public:
    int myArray[QUEUE_CAPACITY];
    int front, rear;
    int count;

    Queue() {
        front = rear = count = 0;
    }

    bool isEmpty() {
        return (count == 0);
    }

    bool isFull() {
        return (count == QUEUE_CAPACITY);
    }

    int getFront() {
        if (!isEmpty()) {
            return myArray[front];
        } else {
            cout << "Queue is empty" << endl;
            return -1;
        }
    }

    void enqueue(int value) {
        if (!isFull()) {
            myArray[rear] = value;
            rear = (rear + 1) % QUEUE_CAPACITY;
            count++;
            cout << "Enqueued" << endl;
        } else {
            cout << "Queue Overflow" << endl;
        }
    }

    void dequeue() {
        if (!isEmpty()) {
            int val = myArray[front];
            front = (front + 1) % QUEUE_CAPACITY;
            count--;
            cout << "Dequeued value = " << val << endl;
        } else {
            cout << "Queue Underflow" << endl;
        }
    }

    void display() {
        if (isEmpty()) {
            cout << "Queue is empty" << endl;
            return;
        }

        cout << "Queue elements are:" << endl;
        int p = front;
        for (int i = 0; i < count; i++) {
            cout << myArray[p] << endl;
            p = (p + 1) % QUEUE_CAPACITY;
        }
    }
};

int main() {
    Queue q;

    q.enqueue(2);
    q.enqueue(3);
    q.display();

    // dequeue can also be used :
    // q.dequeue();
    // q.display();

    return 0;
}
