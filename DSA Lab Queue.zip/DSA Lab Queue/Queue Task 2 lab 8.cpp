#include <iostream>
#include <string>
using namespace std;

struct Truck {
    int id;
    Truck* next;
};
class RoadQueue {
private:
    Truck* front;
    Truck* rear;

public:
    RoadQueue() {
        front = rear = nullptr;
    }

    bool isEmpty() {
        return front == nullptr;
    }

    void enqueue(int truck_id) {
        Truck* newTruck = new Truck{truck_id, nullptr};
        if (rear == nullptr) {
            front = rear = newTruck;
        } else {
            rear->next = newTruck;
            rear = newTruck;
        }
        cout << "Truck " << truck_id << " is now on the road.\n";
    }

    int dequeue() {
        if (isEmpty()) {
            cout << "No trucks on road!\n";
            return -1;
        }
        Truck* temp = front;
        int id = temp->id;
        front = front->next;
        if (front == nullptr)
            rear = nullptr;
        delete temp;
        return id;
    }

    int frontTruck() {
        if (isEmpty()) return -1;
        return front->id;
    }

    void display() {
        if (isEmpty()) {
            cout << "No trucks on the road.\n";
            return;
        }
        cout << "Trucks on road: ";
        Truck* temp = front;
        while (temp != nullptr) {
            cout << temp->id << " ";
            temp = temp->next;
        }
        cout << endl;
    }

    bool contains(int id) {
        Truck* temp = front;
        while (temp != nullptr) {
            if (temp->id == id) return true;
            temp = temp->next;
        }
        return false;
    }
};
class GarageStack {
private:
    Truck* top;

public:
    GarageStack() { top = nullptr; }

    bool isEmpty() {
        return top == nullptr;
    }

    void push(int truck_id) {
        Truck* newTruck = new Truck{truck_id, nullptr};
        newTruck->next = top;
        top = newTruck;
        cout << "Truck " << truck_id << " entered the garage.\n";
    }

    void pop() {
        if (isEmpty()) {
            cout << "Garage is empty!\n";
            return;
        }
        Truck* temp = top;
        cout << "Truck " << top->id << " exited the garage.\n";
        top = top->next;
        delete temp;
    }

    int topTruck() {
        if (isEmpty()) return -1;
        return top->id;
    }

    bool contains(int id) {
        Truck* temp = top;
        while (temp != nullptr) {
            if (temp->id == id) return true;
            temp = temp->next;
        }
        return false;
    }

    void display() {
        if (isEmpty()) {
            cout << "No trucks in garage.\n";
            return;
        }
        cout << "Trucks in garage : ";
        Truck* temp = top;
        while (temp != nullptr) {
            cout << temp->id << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};
class GarageSystem {
private:
    RoadQueue road;
    GarageStack garage;

public:
    void On_road(int truck_id) {
        road.enqueue(truck_id);
    }

    void Enter_garage(int truck_id) {
        if (road.isEmpty()) {
            cout << "No trucks on the road.\n";
            return;
        }
        if (road.frontTruck() == truck_id) {
            road.dequeue();
            garage.push(truck_id);
        } else {
            cout << "Truck " << truck_id << " is not at the front of the road queue.\n";
        }
    }

    void Exit_garage(int truck_id) {
        if (garage.isEmpty()) {
            cout << "Garage is empty!\n";
            return;
        }
        if (garage.topTruck() == truck_id) {
            garage.pop();
        } else {
            cout << "Error: Truck " << truck_id << " is not near the garage door!\n";
        }
    }

    void Show_trucks(string area) {
        if (area == "road")
            road.display();
        else if (area == "garage")
            garage.display();
        else
            cout << "Invalid area. Use 'road' or 'garage'.\n";
    }
};
int main() {
    GarageSystem system;

    system.On_road(101);
    system.On_road(102);
    system.On_road(103);
    system.On_road(104);

    cout << endl;
    system.Show_trucks("road");

    cout << "\n--- Entering Garage ---\n";
    system.Enter_garage(101);
    system.Enter_garage(102);
    system.Enter_garage(103);

    system.Show_trucks("garage");
    system.Show_trucks("road");

    cout << "\n--- Exiting Garage ---\n";
    system.Exit_garage(102); // ? not top
    system.Exit_garage(103); // ? top

    system.Show_trucks("garage");

    cout << "\n--- Final ---\n";
    system.On_road(105);
    system.Enter_garage(104);
    system.Enter_garage(105);
    system.Show_trucks("road");
    system.Show_trucks("garage");

    return 0;
}