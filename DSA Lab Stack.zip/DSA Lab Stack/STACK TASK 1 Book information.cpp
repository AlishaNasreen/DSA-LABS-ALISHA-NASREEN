#include <iostream>
#include <string>
using namespace std;
#define MAX 1000  // Maximum stack size

// Class to represent a Book
class Book {
public:
    string title;
    double price;
    int edition;
    int pages;

    void inputBook() {
        cout << "Enter Book Title: ";
        cin.ignore();
        getline(cin, title);
        cout << "Enter Book Price: ";
        cin >> price;
        cout << "Enter Book Edition: ";
        cin >> edition;
        cout << "Enter Number of Pages: ";
        cin >> pages;
    }

    void displayBook() const {
        cout << "Title: " << title
             << " | Price: " << price
             << " | Edition: " << edition
             << " | Pages: " << pages << endl;
    }
};

// Stack class for storing Book objects
class Stack {
    int top;

public:
    Book books[MAX];  // Array of books

    Stack() {
        top = -1;
    }

    bool push(const Book& b) {
        if (top >= (MAX - 1)) {
            cout << "Stack Overflow\n";
            return false;
        } else {
            books[++top] = b;
            cout << "Book \"" << b.title << "\" pushed into stack.\n";
            return true;
        }
    }

    Book pop() {
        if (top < 0) {
            cout << "Stack Underflow\n";
            return Book(); // return empty Book
        } else {
            Book b = books[top--];
            cout << "Book \"" << b.title << "\" popped from stack.\n";
            return b;
        }
    }

    Book peek() {
        if (top < 0) {
            cout << "Stack is Empty\n";
            return Book();
        } else {
            return books[top];
        }
    }

    bool isEmpty() {
        return (top < 0);
    }

    void displayAll() {
        if (isEmpty()) {
            cout << "Stack is Empty.\n";
            return;
        }

        cout << "\nBooks currently in the stack:\n";
        for (int i = top; i >= 0; i--) {
            cout << "[" << i + 1 << "] ";
            books[i].displayBook();
        }
        cout << endl;
    }
};

// Main function
int main() {
    Stack s;
    Book b;
    int n = 5;

    cout << "*** PUSHING 5 BOOKS INTO STACK ***\n";
    for (int i = 1; i <= n; i++) {
        cout << "\nEnter details for Book " << i << ":\n";
        b.inputBook();
        s.push(b);
    }

    cout << "\n*** TOP BOOK (PEEK) ***\n";
    Book topBook = s.peek();
    cout << "Top Book Details:\n";
    topBook.displayBook();

    cout << "\n*** POPPING 2 BOOKS ***\n";
    s.pop();
    s.pop();

    cout << "\n*** REMAINING BOOKS IN STACK ***\n";
    s.displayAll();

    return 0;
}